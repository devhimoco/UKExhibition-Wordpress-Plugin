<?php
/**
 * Category engine — auto-assigns a category to each exhibition
 * based on keyword matching against title + description.
 *
 * The category list and their keywords are stored in WP options
 * so admins can manage them from Settings → Categories without
 * touching code.
 *
 * Default categories ship with the plugin on first activation.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class RHG_Categories {

	const OPTION_KEY = 'rhg_exh_categories';

	/**
	 * Default category definitions.
	 * Each entry: [ 'name' => '...', 'keywords' => 'comma,separated,words' ]
	 * Keywords are checked (case-insensitive) against exhibition title + description.
	 * Order matters — first match wins.
	 */
	public static function defaults() {
		return array(
			array( 'name' => 'Automotive & Transport',     'keywords' => 'automotive,vehicle,car,motor,fleet,transport,truck,van,driving,automobile' ),
			array( 'name' => 'Aerospace & Defence',        'keywords' => 'aerospace,aviation,defence,defense,military,security,drone,space,air show' ),
			array( 'name' => 'Building & Construction',    'keywords' => 'building,construction,architecture,property,infrastructure,housing,concrete,scaffold,planning' ),
			array( 'name' => 'Energy & Environment',       'keywords' => 'energy,solar,wind,renewable,sustainability,green,environment,climate,biogas,hydrogen,battery,electric' ),
			array( 'name' => 'Electronics & Technology',   'keywords' => 'electronics,technology,tech,digital,computing,software,hardware,IT,cyber,robot,AI,data,network,telecom,connected' ),
			array( 'name' => 'Food & Drink',               'keywords' => 'food,drink,beverage,catering,restaurant,hospitality,bakery,coffee,beer,wine,nutrition,culinary' ),
			array( 'name' => 'Healthcare & Medical',       'keywords' => 'health,medical,pharma,pharmaceutical,dental,clinical,care,hospital,wellness,biotech,life science,therapy' ),
			array( 'name' => 'Fashion & Retail',           'keywords' => 'fashion,retail,clothing,apparel,jewellery,jewelry,gift,lifestyle,luxury,beauty,cosmetics,aesthetics,spa' ),
			array( 'name' => 'Finance & Investment',       'keywords' => 'finance,financial,investment,banking,insurance,fintech,mortgage,wealth,trading,fund' ),
			array( 'name' => 'Marketing & Advertising',   'keywords' => 'marketing,advertising,media,digital marketing,PR,brand,content,social media,creative,design,print' ),
			array( 'name' => 'Manufacturing & Engineering','keywords' => 'manufacturing,engineering,industrial,machinery,process,automation,fabrication,materials,advanced materials' ),
			array( 'name' => 'Logistics & Packaging',      'keywords' => 'logistics,packaging,supply chain,warehouse,delivery,shipping,storage,distribution,pallet' ),
			array( 'name' => 'Real Estate & Property',     'keywords' => 'real estate,property,land,commercial property,residential,housing,estate agent,investment property' ),
			array( 'name' => 'Education & Training',       'keywords' => 'education,training,learning,HR,human resources,employment,skills,career,university,school,coaching' ),
			array( 'name' => 'Science & Research',         'keywords' => 'science,research,R&D,laboratory,lab,chemistry,biology,physics,materials science,innovation' ),
			array( 'name' => 'Agriculture & Horticulture', 'keywords' => 'agriculture,farming,horticulture,garden,crop,livestock,food production,rural' ),
			array( 'name' => 'Sports & Leisure',           'keywords' => 'sport,fitness,leisure,recreation,outdoor,gym,wellness,yoga,running,cycling' ),
			array( 'name' => 'Printing & Publishing',      'keywords' => 'print,printing,publishing,graphic,editorial,media,magazine,book,signage' ),
			array( 'name' => 'Franchise & Business',       'keywords' => 'franchise,franchising,business,entrepreneur,start-up,startup,SME,growth,strategy,consulting' ),
			array( 'name' => 'Other',                       'keywords' => '' ), // catch-all — always last, empty keywords = default fallback for unmatched expos
		);
	}

	/**
	 * Get the live category list (from DB option, or defaults if not set yet).
	 */
	public static function get_all() {
		$saved = get_option( self::OPTION_KEY );
		if ( ! empty( $saved ) && is_array( $saved ) ) {
			return $saved;
		}
		return self::defaults();
	}

	/**
	 * Save category list to DB.
	 */
	public static function save( array $categories ) {
		update_option( self::OPTION_KEY, $categories );
	}

	/**
	 * Return just the category names as a flat array (for dropdowns).
	 */
	public static function get_names() {
		$names = array();
		foreach ( self::get_all() as $cat ) {
			$names[] = $cat['name'];
		}
		return $names;
	}

	/**
	 * Auto-assign a category to an exhibition by matching keywords
	 * against the title and description (case-insensitive).
	 * Returns the first matching category name, or the last category
	 * (catch-all) if nothing matches.
	 */
	public static function auto_assign( $title, $description = '' ) {
		$haystack   = strtolower( $title . ' ' . $description );
		$categories = self::get_all();
		$fallback   = end( $categories )['name'] ?? 'Other';

		foreach ( $categories as $cat ) {
			if ( empty( $cat['keywords'] ) ) {
				continue; // skip the fallback entry during matching
			}

			$keywords = array_map( 'trim', explode( ',', strtolower( $cat['keywords'] ) ) );

			foreach ( $keywords as $kw ) {
				if ( '' !== $kw && strpos( $haystack, $kw ) !== false ) {
					return $cat['name'];
				}
			}
		}

		return $fallback;
	}

	/**
	 * Seed the option with defaults on first activation.
	 * Also migrates existing installs that still have the old
	 * 'Business Services' catch-all name → 'Other'.
	 */
	public static function maybe_seed_defaults() {
		$existing = get_option( self::OPTION_KEY );

		if ( empty( $existing ) ) {
			self::save( self::defaults() );
			return;
		}

		// Migrate: rename old 'Business Services' catch-all to 'Other'
		$changed = false;
		foreach ( $existing as &$cat ) {
			if ( 'Business Services' === $cat['name'] && empty( $cat['keywords'] ) ) {
				$cat['name'] = 'Other';
				$changed     = true;
			}
		}
		unset( $cat );

		if ( $changed ) {
			self::save( $existing );
		}
	}
}
