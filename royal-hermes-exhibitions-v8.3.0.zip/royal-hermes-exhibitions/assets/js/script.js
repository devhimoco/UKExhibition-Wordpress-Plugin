(function ($) {
	'use strict';

	let currentPage        = 1;
	let currentSearch      = '';
	let currentPerPage     = 20; // default 20
	let selectedCategories = []; // multi-select array
	let searchTimer        = null;

	function loadExhibitions() {
		const $grid = $('#rhg-exh-grid');
		$grid.html('<p class="rhg-exh-loading">Loading exhibitions...</p>');

		$.post( rhgExhData.ajaxUrl, {
			action:   'rhg_exh_filter',
			nonce:    rhgExhData.nonce,
			search:   currentSearch,
			category: JSON.stringify( selectedCategories ),
			per_page: currentPerPage,
			page:     currentPage
		}).done(function (response) {
			if ( ! response.success ) {
				$grid.html('<p class="rhg-exh-empty">Something went wrong loading exhibitions.</p>');
				return;
			}
			$grid.html(response.data.html);
			renderPagination(response.data.total_pages, response.data.page);
		}).fail(function () {
			$grid.html('<p class="rhg-exh-empty">Could not load exhibitions. Please try again.</p>');
		});
	}

	function renderPagination(totalPages, page) {
		const $p = $('#rhg-exh-pagination');
		$p.empty();
		if ( totalPages <= 1 ) return;

		for ( let i = 1; i <= totalPages; i++ ) {
			const $btn = $('<button type="button">' + i + '</button>');
			if ( i === page ) $btn.addClass('active');
			$btn.on('click', function () {
				currentPage = i;
				loadExhibitions();
				$('html, body').animate({ scrollTop: $('#rhg-exh-categories').offset().top - 80 }, 250);
			});
			$p.append($btn);
		}
	}

	function updateCategoryUI() {
		$('.rhg-cat-pill').each(function () {
			const cat = $(this).data('category');
			if ( cat === '' ) {
				$(this).toggleClass('active', selectedCategories.length === 0);
			} else {
				$(this).toggleClass('active', selectedCategories.indexOf(cat) !== -1);
			}
		});

		if ( selectedCategories.length > 0 ) {
			$('#rhg-active-cat-name').text( selectedCategories.join(', ') );
			$('#rhg-exh-active-filter').show();
		} else {
			$('#rhg-exh-active-filter').hide();
		}
	}

	function toggleCategory(cat) {
		if ( cat === '' ) {
			selectedCategories = [];
		} else {
			const idx = selectedCategories.indexOf(cat);
			if ( idx === -1 ) {
				selectedCategories.push(cat);
			} else {
				selectedCategories.splice(idx, 1);
			}
		}
		currentPage = 1;
		updateCategoryUI();
		loadExhibitions();
	}

	/* ============================================================
	   CUSTOM COMBO DROPDOWN WIDGET
	   Replaces native <datalist> entirely — datalist mixes browser
	   saved-form-data suggestions into the native dropdown (visible
	   as an inconsistent black list in Edge/Chrome). This widget is
	   fully custom-built and styled, showing ONLY our own data.
	   ============================================================ */

	// Returns the current option list for a given combo key ('job_title',
	// 'country', 'town'). Town depends on whichever country is currently
	// typed in the Country field.
	function getComboItems(comboKey) {
		if (comboKey === 'job_title') {
			return rhgExhData.jobTitles || [];
		}
		if (comboKey === 'country') {
			return rhgExhData.countries || [];
		}
		if (comboKey === 'town') {
			const countryVal = $('#rhg-country-input').val();
			if (!countryVal || !rhgExhData.countryCities) return [];
			const map = rhgExhData.countryCities;
			const matchKey = Object.keys(map).find(
				k => k.toLowerCase() === countryVal.toLowerCase()
			);
			return (matchKey && map[matchKey]) ? map[matchKey] : [];
		}
		return [];
	}

	function renderComboMenu($combo, filterText) {
		const comboKey = $combo.data('combo');
		const $menu    = $combo.find('.rhg-combo-menu');
		const items    = getComboItems(comboKey);
		const filter   = (filterText || '').toLowerCase().trim();

		const filtered = filter
			? items.filter(item => item.toLowerCase().indexOf(filter) !== -1)
			: items;

		$menu.empty();

		if (!items.length) {
			// e.g. Town with no country chosen yet
			const msg = comboKey === 'town' ? 'Select a country first' : 'No suggestions';
			$menu.append($('<li class="rhg-combo-empty">').text(msg));
		} else if (!filtered.length) {
			$menu.append($('<li class="rhg-combo-empty">').text('No matches — you can still type your own'));
		} else {
			filtered.slice(0, 60).forEach(function (item) {
				const $li = $('<li class="rhg-combo-item">').text(item);
				$li.on('mousedown', function (e) {
					// mousedown (not click) so it fires before the input's blur event
					e.preventDefault();
					$combo.find('.rhg-combo-input').val(item).trigger('rhg:comboSelect');
					closeComboMenu($combo);
				});
				$menu.append($li);
			});
		}

		$menu.addClass('open');
	}

	function closeComboMenu($combo) {
		$combo.find('.rhg-combo-menu').removeClass('open').empty();
	}

	function closeAllComboMenus() {
		$('.rhg-combo').each(function () { closeComboMenu($(this)); });
	}

	function initCombos() {
		// Open + filter on input
		$(document).on('input focus', '.rhg-combo-input', function () {
			const $combo = $(this).closest('.rhg-combo');
			renderComboMenu($combo, $(this).val());
		});

		// Toggle menu on arrow icon click
		$(document).on('click', '.rhg-combo-arrow', function () {
			const $combo = $(this).closest('.rhg-combo');
			const $menu  = $combo.find('.rhg-combo-menu');
			if ($menu.hasClass('open')) {
				closeComboMenu($combo);
			} else {
				renderComboMenu($combo, $combo.find('.rhg-combo-input').val());
				$combo.find('.rhg-combo-input').focus();
			}
		});

		// Close menu when clicking elsewhere
		$(document).on('click', function (e) {
			if (!$(e.target).closest('.rhg-combo').length) {
				closeAllComboMenus();
			}
		});

		// Country selection (via click or exact typed match) refreshes Town options
		$(document).on('rhg:comboSelect input', '#rhg-country-input', function () {
			// Clear previously chosen town since it may not belong to the new country
			$('#rhg-town-input').val('');
		});
	}

	/* ============================================================
	   REGISTRATION MODAL
	   ============================================================ */

	function openModal(exhibitionId, shortTitle, date, place) {
		$('#rhg-exh-exhibition-id').val(exhibitionId);
		$('#rhg-exh-modal-title').text(shortTitle);
		$('#rhg-modal-date-val').text(date || '—');
		$('#rhg-modal-place-val').text(place || '—');

		$('#rhg-exh-form-message').removeClass('success error').hide().text('');
		$('#rhg-exh-register-form')[0].reset();
		$('#rhg-exh-exhibition-id').val(exhibitionId);
		closeAllComboMenus();

		$('#rhg-exh-modal').fadeIn(150);
		$('body').css('overflow', 'hidden');
	}

	function closeModal() {
		$('#rhg-exh-modal').fadeOut(150);
		$('body').css('overflow', '');
	}

	function showSuccessPopup(message) {
		$('#rhg-success-message-text').text(message || 'Your registration has been received.');
		closeModal();
		$('#rhg-exh-success-modal').fadeIn(200);
		$('body').css('overflow', 'hidden');
	}

	function closeSuccessPopup() {
		$('#rhg-exh-success-modal').fadeOut(150);
		$('body').css('overflow', '');
	}

	$(document).ready(function () {
		loadExhibitions();
		initCombos();

		// Search with debounce
		$('#rhg-exh-search').on('input', function () {
			clearTimeout(searchTimer);
			const val = $(this).val();
			searchTimer = setTimeout(function () {
				currentSearch = val;
				currentPage   = 1;
				loadExhibitions();
			}, 400);
		});

		// Per-page select
		$('#rhg-exh-per-page').on('change', function () {
			currentPerPage = parseInt($(this).val(), 10);
			currentPage    = 1;
			loadExhibitions();
		});

		// Category pill click — multi-select toggle
		$(document).on('click', '.rhg-cat-pill', function () {
			toggleCategory( $(this).data('category') );
		});

		// Clear all selected categories
		$(document).on('click', '#rhg-clear-filter', function () {
			toggleCategory('');
		});

		// Open registration modal (delegated — cards are re-rendered via AJAX)
		$(document).on('click', '.rhg-exh-register-btn', function () {
			const $card = $(this).closest('.rhg-exh-card');
			openModal(
				$card.data('id'),
				$card.data('short'),
				$card.data('date'),
				$card.data('place')
			);
		});

		// Close registration modal
		$(document).on('click', '.rhg-exh-modal-close, .rhg-exh-modal-overlay', function (e) {
			// Don't close the success popup's overlay by accident when both exist
			if ($(this).closest('#rhg-exh-success-modal').length) return;
			closeModal();
		});

		// Close success popup
		$(document).on('click', '#rhg-success-close', closeSuccessPopup);
		$('#rhg-exh-success-modal .rhg-exh-modal-overlay').on('click', closeSuccessPopup);

		$(document).on('keyup', function (e) {
			if ( e.key === 'Escape' ) {
				closeAllComboMenus();
				closeModal();
				closeSuccessPopup();
			}
		});

		// Submit registration form
		$(document).on('submit', '#rhg-exh-register-form', function (e) {
			e.preventDefault();

			const $form      = $(this);
			const $submitBtn = $form.find('.rhg-exh-submit-btn');
			const $message   = $('#rhg-exh-form-message');

			$submitBtn.prop('disabled', true).text('Submitting...');
			$message.removeClass('success error').hide().text('');

			$.post( rhgExhData.ajaxUrl, {
				action:        'rhg_exh_register',
				nonce:         rhgExhData.nonce,
				exhibition_id: $('#rhg-exh-exhibition-id').val(),
				full_name:     $form.find('[name="full_name"]').val(),
				email:         $form.find('[name="email"]').val(),
				job_title:     $form.find('[name="job_title"]').val(),
				country:       $form.find('[name="country"]').val(),
				town:          $form.find('[name="town"]').val()
			}).done(function (response) {
				if ( response.success ) {
					$form[0].reset();
					showSuccessPopup(response.data.message);
				} else {
					$message.addClass('error').text(response.data.message).show();
				}
			}).fail(function () {
				$message.addClass('error').text('Something went wrong. Please try again.').show();
			}).always(function () {
				$submitBtn.prop('disabled', false).text('Submit Registration');
			});
		});
	});

})(jQuery);
