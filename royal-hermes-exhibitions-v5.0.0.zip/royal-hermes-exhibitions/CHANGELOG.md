# Royal Hermes Exhibitions — Changelog

Versioning rules:
- **+0.1** for small changes (bug fixes, minor UI tweaks, small feature additions)
- **+1.0** for big changes (new pages, new systems, major redesigns, new integrations)
- Starting point: **v5.0.0**

Each zip delivered is named with its version so you can always identify and reinstall a previous release.

---

## v5.0.0 — 2026-07-02
**Major release — starting version**

### What's in this version
- Scrapes UK B2B trade shows daily from EventsEye (no robots.txt blocking, polite 1-second delay between pages)
- Custom DB tables: `rhg_exhibitions` + `rhg_registrations`
- Daily WP-Cron job with manual "Run Scrape Now" button
- Front-end shortcode `[rhg_exhibitions]` with:
  - Live search (debounced)
  - Show 10 / 20 / 40 / 50 dropdown
  - Paginated grid of cards (navy/red/gold brand colours)
  - Registration popup modal per exhibition
  - Server-side email validation (@ + valid domain required)
- Emails on registration: customer confirmation + dual admin notifications
- Admin → Registrations page: filterable by keyword, date range (1/3/7/30 days or specific date), city, category
- Admin → Exhibitions page: only shows exhibitions with ≥1 registration; filterable; click-through to registrant list
- Admin → Settings page: 2 admin notification email fields, scraper controls, shortcode reference
- XAMPP SSL fix baked in (`sslverify => false`, real browser User-Agent)
- Detailed scrape error logging with copy-pasteable admin error box
- Versioned CHANGELOG (this file)

---

## How to read the version number

```
v  5  .  0  .  0
   │     │     └─ patch: tiny fixes (typos, CSS tweaks)
   │     └─ minor: small features or bug fixes  (+0.1 per release)
   └─ major: big new features, pages, integrations  (+1.0 per release)
```

Future entries go at the TOP of this file, newest first.

---

*Next version will be v5.1.0 for the next small change, or v6.0.0 for the next big one.*
