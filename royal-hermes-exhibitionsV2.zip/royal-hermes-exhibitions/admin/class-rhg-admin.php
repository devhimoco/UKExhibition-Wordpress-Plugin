<?php
/**
 * Admin area:
 * - Settings page: admin notification email, manual "scrape now" button.
 * - Registrations page: count per exhibition + drill-down to see all entries.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class RHG_Admin {

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'add_menu' ) );
		add_action( 'admin_init', array( $this, 'handle_actions' ) );
	}

	public function add_menu() {
		add_menu_page(
			'Exhibitions',
			'Exhibitions',
			'manage_options',
			'rhg-exhibitions',
			array( $this, 'render_registrations_page' ),
			'dashicons-tickets-alt',
			26
		);

		add_submenu_page(
			'rhg-exhibitions',
			'Registrations',
			'Registrations',
			'manage_options',
			'rhg-exhibitions',
			array( $this, 'render_registrations_page' )
		);

		add_submenu_page(
			'rhg-exhibitions',
			'Settings',
			'Settings',
			'manage_options',
			'rhg-exhibitions-settings',
			array( $this, 'render_settings_page' )
		);
	}

	public function handle_actions() {
		if ( isset( $_POST['rhg_exh_save_settings'] ) && check_admin_referer( 'rhg_exh_settings_nonce' ) ) {
			$email = sanitize_email( $_POST['rhg_exh_admin_email'] );
			update_option( 'rhg_exh_admin_email', $email );
			add_settings_error( 'rhg_exh_settings', 'saved', 'Settings saved.', 'updated' );
		}

		if ( isset( $_POST['rhg_exh_run_scrape_now'] ) && check_admin_referer( 'rhg_exh_settings_nonce' ) ) {
			$count = RHG_Scraper::run();
			add_settings_error( 'rhg_exh_settings', 'scraped', sprintf( 'Scrape complete: %d exhibitions saved/updated.', $count ), 'updated' );
		}
	}

	public function render_settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$admin_email = get_option( 'rhg_exh_admin_email', get_option( 'admin_email' ) );
		$last_run    = get_option( 'rhg_exh_last_run' );
		$last_count  = get_option( 'rhg_exh_last_run_count' );
		?>
		<div class="wrap">
			<h1>Royal Hermes Exhibitions — Settings</h1>

			<?php settings_errors( 'rhg_exh_settings' ); ?>

			<?php
			$last_error  = get_option( 'rhg_exh_last_error' );
			$last_status = get_option( 'rhg_exh_last_http_status' );
			$last_length = get_option( 'rhg_exh_last_body_length' );
			if ( ! empty( $last_error ) ) :
				?>
				<div class="notice notice-error" style="padding:16px; border-left-width:6px;">
					<p style="font-size:15px; margin:0 0 8px;"><strong>⚠️ Last scrape error — copy this and send it to support:</strong></p>
					<textarea readonly rows="4" style="width:100%; font-family:monospace; font-size:13px; background:#fff; padding:10px;"><?php echo esc_textarea( $last_error ); ?></textarea>
				</div>
			<?php elseif ( $last_status ) : ?>
				<div class="notice notice-info" style="padding:12px 16px;">
					<p><strong>Last successful fetch:</strong> HTTP <?php echo esc_html( $last_status ); ?>, <?php echo esc_html( number_format( (int) $last_length ) ); ?> bytes received.</p>
				</div>
			<?php endif; ?>

			<div class="notice notice-warning" style="padding:12px 16px; margin-top:10px;">
				<p><strong>Running on XAMPP locally?</strong> Local servers often can't make outbound HTTPS requests due to missing CA certificates or a firewall. If the error above mentions SSL, cURL, or "could not resolve host," see the README inside the plugin zip for the XAMPP fix (updating <code>php.ini</code>'s <code>curl.cainfo</code> path).</p>
			</div>

			<div class="notice notice-warning" style="padding:12px 16px;">
				<p><strong>Email delivery note:</strong> WordPress's default mail sending often fails or lands in spam on most hosting setups. For reliable delivery of registration emails, please install a free SMTP plugin such as <strong>WP Mail SMTP</strong> or <strong>Easy WP SMTP</strong> and connect it to a real mail provider (Gmail, Outlook, or a free SendGrid/Mailgun account). Without this, emails may not arrive.</p>
			</div>

			<form method="post">
				<?php wp_nonce_field( 'rhg_exh_settings_nonce' ); ?>
				<table class="form-table">
					<tr>
						<th scope="row"><label for="rhg_exh_admin_email">Admin notification email</label></th>
						<td>
							<input type="email" id="rhg_exh_admin_email" name="rhg_exh_admin_email" value="<?php echo esc_attr( $admin_email ); ?>" class="regular-text" />
							<p class="description">Where new registration alerts are sent. Defaults to your WordPress admin email.</p>
						</td>
					</tr>
				</table>
				<p class="submit">
					<input type="submit" name="rhg_exh_save_settings" class="button button-primary" value="Save Settings" />
				</p>
			</form>

			<hr />

			<h2>Exhibition Data</h2>
			<p>
				<?php if ( $last_run ) : ?>
					Last scrape: <strong><?php echo esc_html( date( 'd M Y, H:i', strtotime( $last_run ) ) ); ?></strong>
					— <?php echo esc_html( (int) $last_count ); ?> exhibitions saved/updated.
				<?php else : ?>
					No scrape has run yet.
				<?php endif; ?>
				This runs automatically once a day.
			</p>

			<form method="post">
				<?php wp_nonce_field( 'rhg_exh_settings_nonce' ); ?>
				<input type="submit" name="rhg_exh_run_scrape_now" class="button button-secondary" value="Run Scrape Now" />
			</form>

			<hr />

			<h2>How to display exhibitions on your site</h2>
			<p>Add this shortcode to any page or post:</p>
			<code>[rhg_exhibitions]</code>
		</div>
		<?php
	}

	public function render_registrations_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$view = isset( $_GET['view'] ) ? sanitize_text_field( $_GET['view'] ) : 'summary';
		$exhibition_id = isset( $_GET['exhibition_id'] ) ? absint( $_GET['exhibition_id'] ) : 0;
		?>
		<div class="wrap">
			<h1>Exhibition Registrations</h1>

			<?php if ( 'detail' === $view && $exhibition_id ) : ?>
				<?php $this->render_detail_view( $exhibition_id ); ?>
			<?php else : ?>
				<?php $this->render_summary_view(); ?>
			<?php endif; ?>
		</div>
		<?php
	}

	private function render_summary_view() {
		$rows = RHG_DB::get_registration_counts();
		?>
		<table class="wp-list-table widefat fixed striped">
			<thead>
				<tr>
					<th>Exhibition</th>
					<th>Date</th>
					<th>City</th>
					<th>Total Registrations</th>
					<th>Action</th>
				</tr>
			</thead>
			<tbody>
				<?php if ( empty( $rows ) ) : ?>
					<tr><td colspan="5">No exhibitions found yet. Run a scrape from the Settings page.</td></tr>
				<?php else : ?>
					<?php foreach ( $rows as $row ) : ?>
						<tr>
							<td><strong><?php echo esc_html( $row->title ); ?></strong></td>
							<td><?php echo esc_html( $row->start_date ? date( 'd M Y', strtotime( $row->start_date ) ) : '—' ); ?></td>
							<td><?php echo esc_html( $row->city ); ?></td>
							<td><?php echo esc_html( $row->total_registrations ); ?></td>
							<td>
								<a href="<?php echo esc_url( admin_url( 'admin.php?page=rhg-exhibitions&view=detail&exhibition_id=' . $row->id ) ); ?>" class="button button-small">View Registrations</a>
							</td>
						</tr>
					<?php endforeach; ?>
				<?php endif; ?>
			</tbody>
		</table>

		<h2 style="margin-top:40px;">All Registrations (every exhibition)</h2>
		<?php $this->render_registrations_table( RHG_DB::get_all_registrations(), true ); ?>
		<?php
	}

	private function render_detail_view( $exhibition_id ) {
		$exhibition = RHG_DB::get_exhibition_by_id( $exhibition_id );

		if ( ! $exhibition ) {
			echo '<p>Exhibition not found.</p>';
			return;
		}
		?>
		<p>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=rhg-exhibitions' ) ); ?>">&larr; Back to all exhibitions</a>
		</p>
		<h2><?php echo esc_html( $exhibition->title ); ?></h2>
		<p>
			<?php echo esc_html( $exhibition->start_date ? date( 'd M Y', strtotime( $exhibition->start_date ) ) : '' ); ?>
			&middot; <?php echo esc_html( $exhibition->venue ); ?>, <?php echo esc_html( $exhibition->city ); ?>
		</p>

		<?php $this->render_registrations_table( RHG_DB::get_registrations_for_exhibition( $exhibition_id ), false ); ?>
		<?php
	}

	private function render_registrations_table( $rows, $show_exhibition_column ) {
		?>
		<table class="wp-list-table widefat fixed striped">
			<thead>
				<tr>
					<?php if ( $show_exhibition_column ) : ?><th>Exhibition</th><?php endif; ?>
					<th>Name</th>
					<th>Email</th>
					<th>Job Title</th>
					<th>Country</th>
					<th>Town</th>
					<th>Registered On</th>
				</tr>
			</thead>
			<tbody>
				<?php if ( empty( $rows ) ) : ?>
					<tr><td colspan="<?php echo $show_exhibition_column ? 7 : 6; ?>">No registrations yet.</td></tr>
				<?php else : ?>
					<?php foreach ( $rows as $row ) : ?>
						<tr>
							<?php if ( $show_exhibition_column ) : ?>
								<td><?php echo esc_html( $row->exhibition_title ); ?></td>
							<?php endif; ?>
							<td><?php echo esc_html( $row->full_name ); ?></td>
							<td><?php echo esc_html( $row->email ); ?></td>
							<td><?php echo esc_html( $row->job_title ); ?></td>
							<td><?php echo esc_html( $row->country ); ?></td>
							<td><?php echo esc_html( $row->town ); ?></td>
							<td><?php echo esc_html( date( 'd M Y, H:i', strtotime( $row->created_at ) ) ); ?></td>
						</tr>
					<?php endforeach; ?>
				<?php endif; ?>
			</tbody>
		</table>
		<?php
	}
}
