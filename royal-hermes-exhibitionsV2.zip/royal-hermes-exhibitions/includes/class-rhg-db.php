<?php
/**
 * Handles custom database tables:
 * - {prefix}rhg_exhibitions      : scraped exhibition listings
 * - {prefix}rhg_registrations    : visitor sign-ups per exhibition
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class RHG_DB {

	public static function exhibitions_table() {
		global $wpdb;
		return $wpdb->prefix . 'rhg_exhibitions';
	}

	public static function registrations_table() {
		global $wpdb;
		return $wpdb->prefix . 'rhg_registrations';
	}

	/**
	 * Create both tables. Safe to call repeatedly (dbDelta handles diffing).
	 */
	public static function create_tables() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset_collate = $wpdb->get_charset_collate();
		$exh_table       = self::exhibitions_table();
		$reg_table       = self::registrations_table();

		$sql_exhibitions = "CREATE TABLE $exh_table (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			source_url VARCHAR(500) NOT NULL,
			slug VARCHAR(255) NOT NULL,
			title VARCHAR(255) NOT NULL,
			description TEXT NULL,
			city VARCHAR(150) NULL,
			venue VARCHAR(255) NULL,
			start_date DATE NULL,
			end_date DATE NULL,
			cycle VARCHAR(100) NULL,
			image_url VARCHAR(500) NULL,
			category VARCHAR(150) NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'published',
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY slug (slug),
			KEY start_date (start_date),
			KEY city (city)
		) $charset_collate;";

		$sql_registrations = "CREATE TABLE $reg_table (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			exhibition_id BIGINT(20) UNSIGNED NOT NULL,
			full_name VARCHAR(255) NOT NULL,
			email VARCHAR(255) NOT NULL,
			job_title VARCHAR(255) NULL,
			country VARCHAR(150) NULL,
			town VARCHAR(150) NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY exhibition_id (exhibition_id),
			KEY email (email)
		) $charset_collate;";

		dbDelta( $sql_exhibitions );
		dbDelta( $sql_registrations );
	}

	/**
	 * Insert a new exhibition or update an existing one (matched by slug).
	 * Returns the row ID.
	 */
	public static function upsert_exhibition( array $data ) {
		global $wpdb;
		$table = self::exhibitions_table();
		$now   = current_time( 'mysql' );

		$existing_id = $wpdb->get_var(
			$wpdb->prepare( "SELECT id FROM $table WHERE slug = %s", $data['slug'] )
		);

		if ( $existing_id ) {
			$wpdb->update(
				$table,
				array(
					'title'       => $data['title'],
					'description' => $data['description'],
					'city'        => $data['city'],
					'venue'       => $data['venue'],
					'start_date'  => $data['start_date'],
					'end_date'    => $data['end_date'],
					'cycle'       => $data['cycle'],
					'image_url'   => $data['image_url'],
					'category'    => $data['category'],
					'source_url'  => $data['source_url'],
					'updated_at'  => $now,
				),
				array( 'id' => $existing_id )
			);
			return (int) $existing_id;
		}

		$wpdb->insert(
			$table,
			array(
				'source_url'  => $data['source_url'],
				'slug'        => $data['slug'],
				'title'       => $data['title'],
				'description' => $data['description'],
				'city'        => $data['city'],
				'venue'       => $data['venue'],
				'start_date'  => $data['start_date'],
				'end_date'    => $data['end_date'],
				'cycle'       => $data['cycle'],
				'image_url'   => $data['image_url'],
				'category'    => $data['category'],
				'status'      => 'published',
				'created_at'  => $now,
				'updated_at'  => $now,
			)
		);
		return (int) $wpdb->insert_id;
	}

	/**
	 * Fetch a paginated, optionally-searched list of exhibitions.
	 */
	public static function get_exhibitions( $search = '', $per_page = 10, $page = 1 ) {
		global $wpdb;
		$table  = self::exhibitions_table();
		$offset = max( 0, ( $page - 1 ) * $per_page );

		$where  = "WHERE status = 'published'";
		$params = array();

		if ( ! empty( $search ) ) {
			$where   .= ' AND (title LIKE %s OR city LIKE %s OR venue LIKE %s OR category LIKE %s)';
			$like     = '%' . $wpdb->esc_like( $search ) . '%';
			$params   = array( $like, $like, $like, $like );
		}

		$count_sql = "SELECT COUNT(*) FROM $table $where";
		$total     = $params ? $wpdb->get_var( $wpdb->prepare( $count_sql, $params ) ) : $wpdb->get_var( $count_sql );

		$sql = "SELECT * FROM $table $where ORDER BY start_date ASC LIMIT %d OFFSET %d";
		$params[] = $per_page;
		$params[] = $offset;

		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $params ) );

		return array(
			'rows'  => $rows,
			'total' => (int) $total,
		);
	}

	public static function get_exhibition_by_id( $id ) {
		global $wpdb;
		$table = self::exhibitions_table();
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id = %d", $id ) );
	}

	/**
	 * Save a registration entry.
	 */
	public static function add_registration( array $data ) {
		global $wpdb;
		$table = self::registrations_table();

		$wpdb->insert(
			$table,
			array(
				'exhibition_id' => $data['exhibition_id'],
				'full_name'     => $data['full_name'],
				'email'         => $data['email'],
				'job_title'     => $data['job_title'],
				'country'       => $data['country'],
				'town'          => $data['town'],
				'created_at'    => current_time( 'mysql' ),
			)
		);

		return (int) $wpdb->insert_id;
	}

	/**
	 * Admin: registration counts grouped by exhibition.
	 */
	public static function get_registration_counts() {
		global $wpdb;
		$exh_table = self::exhibitions_table();
		$reg_table = self::registrations_table();

		$sql = "SELECT e.id, e.title, e.start_date, e.city, COUNT(r.id) AS total_registrations
				FROM $exh_table e
				LEFT JOIN $reg_table r ON r.exhibition_id = e.id
				GROUP BY e.id
				ORDER BY e.start_date ASC";

		return $wpdb->get_results( $sql );
	}

	/**
	 * Admin: all registrations for one exhibition.
	 */
	public static function get_registrations_for_exhibition( $exhibition_id ) {
		global $wpdb;
		$table = self::registrations_table();
		return $wpdb->get_results(
			$wpdb->prepare( "SELECT * FROM $table WHERE exhibition_id = %d ORDER BY created_at DESC", $exhibition_id )
		);
	}

	/**
	 * Admin: every registration across all exhibitions (joined with exhibition title).
	 */
	public static function get_all_registrations() {
		global $wpdb;
		$exh_table = self::exhibitions_table();
		$reg_table = self::registrations_table();

		$sql = "SELECT r.*, e.title AS exhibition_title
				FROM $reg_table r
				LEFT JOIN $exh_table e ON e.id = r.exhibition_id
				ORDER BY r.created_at DESC";

		return $wpdb->get_results( $sql );
	}
}
