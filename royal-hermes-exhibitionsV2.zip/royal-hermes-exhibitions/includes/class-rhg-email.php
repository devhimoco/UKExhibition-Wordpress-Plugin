<?php
/**
 * Sends registration confirmation emails using wp_mail().
 *
 * IMPORTANT: wp_mail() relies on the server's mail setup, which is
 * unreliable on most hosts (emails often fail silently or land in spam).
 * For real-world reliability, install a free SMTP plugin such as
 * "WP Mail SMTP" or "Easy WP SMTP" and connect it to a real mail
 * provider (Gmail, Outlook, SendGrid free tier, etc).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class RHG_Email {

	/**
	 * Send both the admin notification and the customer confirmation.
	 */
	public static function send_registration_emails( $registration, $exhibition ) {
		self::send_admin_notification( $registration, $exhibition );
		self::send_customer_confirmation( $registration, $exhibition );
	}

	private static function admin_email() {
		$option = get_option( 'rhg_exh_admin_email' );
		return ! empty( $option ) ? $option : get_option( 'admin_email' );
	}

	private static function send_admin_notification( $registration, $exhibition ) {
		$to      = self::admin_email();
		$subject = sprintf( '[Royal Hermes Group] New registration: %s', $exhibition->title );

		$body  = "A new registration has been received.\n\n";
		$body .= 'Exhibition: ' . $exhibition->title . "\n";
		$body .= 'Date: ' . esc_html( $exhibition->start_date ) . "\n";
		$body .= 'City/Venue: ' . esc_html( $exhibition->city . ' - ' . $exhibition->venue ) . "\n\n";
		$body .= "Registrant details:\n";
		$body .= 'Name: ' . $registration['full_name'] . "\n";
		$body .= 'Email: ' . $registration['email'] . "\n";
		$body .= 'Job title: ' . $registration['job_title'] . "\n";
		$body .= 'Country: ' . $registration['country'] . "\n";
		$body .= 'Town: ' . $registration['town'] . "\n";

		wp_mail( $to, $subject, $body );
	}

	private static function send_customer_confirmation( $registration, $exhibition ) {
		$to      = $registration['email'];
		$subject = sprintf( 'Your registration for %s is confirmed', $exhibition->title );

		$body  = 'Hi ' . $registration['full_name'] . ",\n\n";
		$body .= "Thank you for registering. Here are your details:\n\n";
		$body .= 'Exhibition: ' . $exhibition->title . "\n";
		$body .= 'Date: ' . esc_html( $exhibition->start_date ) . "\n";
		$body .= 'Venue: ' . esc_html( $exhibition->venue ) . ', ' . esc_html( $exhibition->city ) . "\n\n";
		$body .= "We will be in touch with further details.\n\n";
		$body .= "Best regards,\nRoyal Hermes Group";

		wp_mail( $to, $subject, $body );
	}
}
