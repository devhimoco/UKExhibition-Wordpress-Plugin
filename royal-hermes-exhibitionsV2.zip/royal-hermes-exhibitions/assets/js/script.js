(function ($) {
	'use strict';

	let currentPage = 1;
	let currentSearch = '';
	let currentPerPage = 10;
	let searchTimer = null;

	function loadExhibitions() {
		const $grid = $('#rhg-exh-grid');
		$grid.html('<p class="rhg-exh-loading">Loading exhibitions...</p>');

		$.post(rhgExhData.ajaxUrl, {
			action: 'rhg_exh_filter',
			nonce: rhgExhData.nonce,
			search: currentSearch,
			per_page: currentPerPage,
			page: currentPage
		}).done(function (response) {
			if (!response.success) {
				$grid.html('<p class="rhg-exh-empty">Something went wrong loading exhibitions.</p>');
				return;
			}

			$grid.html(response.data.html);
			renderPagination(response.data.total_pages, response.data.page);
		}).fail(function () {
			$grid.html('<p class="rhg-exh-empty">Could not load exhibitions. Please try again.</p>');
		});
	}

	function renderPagination(totalPages, page) {
		const $pagination = $('#rhg-exh-pagination');
		$pagination.empty();

		if (totalPages <= 1) {
			return;
		}

		for (let i = 1; i <= totalPages; i++) {
			const $btn = $('<button type="button">' + i + '</button>');
			if (i === page) {
				$btn.addClass('active');
			}
			$btn.on('click', function () {
				currentPage = i;
				loadExhibitions();
			});
			$pagination.append($btn);
		}
	}

	function openModal(exhibitionId, title, date, place) {
		$('#rhg-exh-exhibition-id').val(exhibitionId);
		$('#rhg-exh-modal-title').text('Register: ' + title);

		let subtitle = [];
		if (date) subtitle.push(date);
		if (place) subtitle.push(place);
		$('#rhg-exh-modal-subtitle').text(subtitle.join(' · '));

		$('#rhg-exh-form-message').removeClass('success error').hide().text('');
		$('#rhg-exh-register-form')[0].reset();
		$('#rhg-exh-exhibition-id').val(exhibitionId);

		$('#rhg-exh-modal').fadeIn(150);
		$('body').css('overflow', 'hidden');
	}

	function closeModal() {
		$('#rhg-exh-modal').fadeOut(150);
		$('body').css('overflow', '');
	}

	$(document).ready(function () {
		loadExhibitions();

		// Search with debounce.
		$('#rhg-exh-search').on('input', function () {
			clearTimeout(searchTimer);
			const val = $(this).val();
			searchTimer = setTimeout(function () {
				currentSearch = val;
				currentPage = 1;
				loadExhibitions();
			}, 400);
		});

		// Per-page select.
		$('#rhg-exh-per-page').on('change', function () {
			currentPerPage = parseInt($(this).val(), 10);
			currentPage = 1;
			loadExhibitions();
		});

		// Open registration modal (delegated, since cards are re-rendered via AJAX).
		$(document).on('click', '.rhg-exh-register-btn', function () {
			const $card = $(this).closest('.rhg-exh-card');
			openModal(
				$card.data('id'),
				$card.data('title'),
				$card.data('date'),
				$card.data('place')
			);
		});

		// Close modal.
		$(document).on('click', '.rhg-exh-modal-close, .rhg-exh-modal-overlay', closeModal);

		$(document).on('keyup', function (e) {
			if (e.key === 'Escape') {
				closeModal();
			}
		});

		// Submit registration form.
		$(document).on('submit', '#rhg-exh-register-form', function (e) {
			e.preventDefault();

			const $form = $(this);
			const $submitBtn = $form.find('.rhg-exh-submit-btn');
			const $message = $('#rhg-exh-form-message');

			$submitBtn.prop('disabled', true).text('Submitting...');
			$message.removeClass('success error').hide().text('');

			const formData = {
				action: 'rhg_exh_register',
				nonce: rhgExhData.nonce,
				exhibition_id: $('#rhg-exh-exhibition-id').val(),
				full_name: $form.find('[name="full_name"]').val(),
				email: $form.find('[name="email"]').val(),
				job_title: $form.find('[name="job_title"]').val(),
				country: $form.find('[name="country"]').val(),
				town: $form.find('[name="town"]').val()
			};

			$.post(rhgExhData.ajaxUrl, formData)
				.done(function (response) {
					if (response.success) {
						$message.addClass('success').text(response.data.message).show();
						$form[0].reset();
						setTimeout(closeModal, 1800);
					} else {
						$message.addClass('error').text(response.data.message).show();
					}
				})
				.fail(function () {
					$message.addClass('error').text('Something went wrong. Please try again.').show();
				})
				.always(function () {
					$submitBtn.prop('disabled', false).text('Submit Registration');
				});
		});
	});
})(jQuery);
