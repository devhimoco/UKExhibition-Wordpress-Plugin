<?php
/**
 * [rhg_exhibitions] shortcode — searchable, paginated 4-column grid
 * with category filter pills. Default: 20 per page.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class RHG_Shortcode {

	public function __construct() {
		add_shortcode( 'rhg_exhibitions', array( __CLASS__, 'render' ) );
	}

	public static function countries() {
		return array(
			'United Kingdom', 'Ireland', 'France', 'Germany', 'Spain', 'Italy',
			'Netherlands', 'Belgium', 'Portugal', 'Switzerland', 'Sweden',
			'Norway', 'Denmark', 'Poland', 'United States', 'Canada',
			'United Arab Emirates', 'Saudi Arabia', 'India', 'China', 'Other',
		);
	}

	public static function uk_towns() {
		return array(
			'London', 'Birmingham', 'Manchester', 'Glasgow', 'Edinburgh',
			'Bristol', 'Leeds', 'Liverpool', 'Sheffield', 'Newcastle',
			'Belfast', 'Cardiff', 'Coventry', 'Harrogate', 'Aberdeen',
			'Southampton', 'Oxford', 'Cambridge', 'Other',
		);
	}

	public static function render( $atts ) {
		$categories = RHG_Categories::get_names();
		ob_start();
		?>
		<div class="rhg-exh-wrapper">

			<!-- Search + per-page row -->
			<div class="rhg-exh-controls">
				<input
					type="text"
					id="rhg-exh-search"
					class="rhg-exh-search-input"
					placeholder="Search by exhibition, city, or venue..."
				/>
				<select id="rhg-exh-per-page" class="rhg-exh-select">
					<option value="10">Show 10</option>
					<option value="20" selected>Show 20</option>
					<option value="40">Show 40</option>
					<option value="50">Show 50</option>
				</select>
			</div>

			<!-- Category filter pills -->
			<div class="rhg-exh-categories" id="rhg-exh-categories">
				<button type="button" class="rhg-cat-pill active" data-category="">All Categories</button>
				<?php foreach ( $categories as $cat ) : ?>
					<button type="button" class="rhg-cat-pill" data-category="<?php echo esc_attr( $cat ); ?>">
						<?php echo esc_html( $cat ); ?>
					</button>
				<?php endforeach; ?>
			</div>

			<!-- Active filter label -->
			<div id="rhg-exh-active-filter" class="rhg-exh-active-filter" style="display:none;">
				Filtered by: <strong id="rhg-active-cat-name"></strong>
				<button type="button" id="rhg-clear-filter" class="rhg-clear-filter">&times; Clear all</button>
			</div>

			<!-- Grid -->
			<div id="rhg-exh-grid" class="rhg-exh-grid">
				<p class="rhg-exh-loading">Loading exhibitions...</p>
			</div>

			<div id="rhg-exh-pagination" class="rhg-exh-pagination"></div>

			<p class="rhg-exh-updated">
				<?php
				$last_run = get_option( 'rhg_exh_last_run' );
				if ( $last_run ) {
					echo 'Listings last updated: ' . esc_html( date( 'd M Y, H:i', strtotime( $last_run ) ) );
				}
				?>
			</p>

		</div>

		<?php self::render_modal(); ?>
		<?php
		return ob_get_clean();
	}

	public static function render_card( $exhibition ) {
		$image = ! empty( $exhibition->image_url )
			? esc_url( $exhibition->image_url )
			: RHG_EXH_URL . 'assets/img/placeholder.jpg';

		// Short title
		$short_title = $exhibition->title;
		foreach ( array( ' - ', ' – ', ' | ' ) as $sep ) {
			if ( strpos( $short_title, $sep ) !== false ) {
				$short_title = trim( explode( $sep, $short_title )[0] );
				break;
			}
		}
		if ( mb_strlen( $short_title ) > 44 ) {
			$short_title = mb_substr( $short_title, 0, 42 ) . '…';
		}

		// Date — always show the exact scraped date if we have it
		$date_display = '';
		$start_ts     = null;
		if ( ! empty( $exhibition->start_date ) ) {
			$start_ts     = strtotime( $exhibition->start_date );
			$date_display = date( 'd M Y', $start_ts );
			if ( ! empty( $exhibition->end_date ) && $exhibition->end_date !== $exhibition->start_date ) {
				$date_display .= ' – ' . date( 'd M Y', strtotime( $exhibition->end_date ) );
			}
		}

		// Days left — only shown when date is available
		$days_left_html = '';
		if ( $start_ts ) {
			$today     = strtotime( date( 'Y-m-d' ) );
			$diff_days = (int) round( ( $start_ts - $today ) / 86400 );
			if ( $diff_days > 0 ) {
				$days_left_html = '<strong class="rhg-days-left">' . number_format( $diff_days ) . ' day' . ( $diff_days !== 1 ? 's' : '' ) . ' to go</strong>';
			} elseif ( $diff_days === 0 ) {
				$days_left_html = '<strong class="rhg-days-left rhg-days-today">Today!</strong>';
			} else {
				$days_left_html = '<span class="rhg-days-past">Ended ' . abs( $diff_days ) . 'd ago</span>';
			}
		}

		// Cycle
		$cycle = ! empty( $exhibition->cycle ) ? $exhibition->cycle : '';

		// Location
		$place = trim( implode( ', ', array_filter( array( $exhibition->venue, $exhibition->city ) ) ) );

		// Full description for overlay (no truncation — card height accommodates it)
		$description = ! empty( $exhibition->description )
			? $exhibition->description
			: 'Click Register to secure your place at this exhibition.';
		?>
		<div class="rhg-exh-card"
			data-id="<?php echo esc_attr( $exhibition->id ); ?>"
			data-title="<?php echo esc_attr( $exhibition->title ); ?>"
			data-short="<?php echo esc_attr( $short_title ); ?>"
			data-date="<?php echo esc_attr( $date_display ); ?>"
			data-place="<?php echo esc_attr( $place ); ?>"
		>
			<!-- Image band -->
			<div class="rhg-exh-card-image" style="background-image:url('<?php echo $image; ?>');">
				<span class="rhg-exh-card-category"><?php echo esc_html( $exhibition->category ?: 'Exhibition' ); ?></span>
			</div>

			<!-- Card body — always visible -->
			<div class="rhg-exh-card-body">
				<h3 class="rhg-exh-card-title"><?php echo esc_html( $short_title ); ?></h3>

				<?php if ( $date_display ) : ?>
				<p class="rhg-exh-card-meta">
					<span class="rhg-exh-icon-date"></span> <?php echo esc_html( $date_display ); ?>
				</p>
				<?php endif; ?>

				<?php if ( $days_left_html ) : ?>
				<p class="rhg-exh-card-meta rhg-meta-days"><?php echo $days_left_html; ?></p>
				<?php endif; ?>

				<?php if ( $place ) : ?>
				<p class="rhg-exh-card-meta">
					<span class="rhg-exh-icon-place"></span> <?php echo esc_html( $place ); ?>
				</p>
				<?php endif; ?>

				<?php if ( $cycle ) : ?>
				<p class="rhg-exh-card-meta rhg-meta-cycle">
					<span class="rhg-exh-icon-cycle"></span> <?php echo esc_html( $cycle ); ?>
				</p>
				<?php endif; ?>
			</div>

			<!-- Red hover overlay — fills the whole card -->
			<div class="rhg-exh-card-overlay">
				<div class="rhg-exh-overlay-inner">
					<h4 class="rhg-overlay-title"><?php echo esc_html( $exhibition->title ); ?></h4>

					<?php if ( $date_display ) : ?>
					<p class="rhg-overlay-date">
						📅 <?php echo esc_html( $date_display ); ?>
						<?php if ( $days_left_html ) echo '&nbsp;' . $days_left_html; ?>
					</p>
					<?php endif; ?>

					<?php if ( $place ) : ?>
					<p class="rhg-overlay-place">📍 <?php echo esc_html( $place ); ?></p>
					<?php endif; ?>

					<?php if ( $cycle ) : ?>
					<p class="rhg-overlay-cycle">🔁 <?php echo esc_html( $cycle ); ?></p>
					<?php endif; ?>

					<hr class="rhg-overlay-divider" />
					<p class="rhg-overlay-desc"><?php echo esc_html( $description ); ?></p>
					<button type="button" class="rhg-exh-register-btn">
						Register <span class="rhg-exh-arrow">&rarr;</span>
					</button>
				</div>
			</div>

		</div>
		<?php
	}

	private static function render_modal() {
		$logo_url = RHG_EXH_URL . 'assets/img/logo.png';
		?>
		<div id="rhg-exh-modal" class="rhg-exh-modal" style="display:none;">
			<div class="rhg-exh-modal-overlay"></div>
			<div class="rhg-exh-modal-box">
				<button type="button" class="rhg-exh-modal-close">&times;</button>

				<!-- Modal header: logo + expo short info -->
				<div class="rhg-modal-header">
					<img src="<?php echo esc_url( $logo_url ); ?>" alt="Royal Hermes Group" class="rhg-modal-logo" />
					<div class="rhg-modal-header-info">
						<h3 id="rhg-exh-modal-title" class="rhg-modal-expo-name"></h3>
						<p id="rhg-modal-date" class="rhg-modal-meta"><span class="rhg-icon-sm">📅</span> <span id="rhg-modal-date-val"></span></p>
						<p id="rhg-modal-place" class="rhg-modal-meta"><span class="rhg-icon-sm">📍</span> <span id="rhg-modal-place-val"></span></p>
					</div>
				</div>

				<div class="rhg-modal-divider"></div>

				<form id="rhg-exh-register-form">
					<input type="hidden" name="exhibition_id" id="rhg-exh-exhibition-id" value="" />

					<label>Full Name *</label>
					<input type="text" name="full_name" required />

					<label>Email *</label>
					<input type="email" name="email" required placeholder="name@example.com" />

					<label>Job Title *</label>
					<input type="text" name="job_title" required />

					<label>Country *</label>
					<select name="country" required>
						<option value="">Select country</option>
						<?php foreach ( self::countries() as $country ) : ?>
							<option value="<?php echo esc_attr( $country ); ?>"><?php echo esc_html( $country ); ?></option>
						<?php endforeach; ?>
					</select>

					<label>Town *</label>
					<select name="town" required>
						<option value="">Select town</option>
						<?php foreach ( self::uk_towns() as $town ) : ?>
							<option value="<?php echo esc_attr( $town ); ?>"><?php echo esc_html( $town ); ?></option>
						<?php endforeach; ?>
					</select>

					<div id="rhg-exh-form-message" class="rhg-exh-form-message"></div>

					<button type="submit" class="rhg-exh-submit-btn">Submit Registration</button>
				</form>
			</div>
		</div>
		<?php
	}
}
