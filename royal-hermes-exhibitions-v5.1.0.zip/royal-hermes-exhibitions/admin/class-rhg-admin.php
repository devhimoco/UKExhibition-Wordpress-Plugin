<?php
/**
 * Admin area — 3 pages:
 * 1. Registrations  : table of everyone who registered, searchable/filterable.
 * 2. Exhibitions    : all scraped exhibitions with filters; only shows those
 *                     that have at least 1 registration — click through to see
 *                     the individual registrants for that expo.
 * 3. Settings       : 2 admin notification emails + scrape controls.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class RHG_Admin {

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'add_menu' ) );
		add_action( 'admin_init', array( $this, 'handle_actions' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );
	}

	/* ------------------------------------------------------------------ */
	/* MENU                                                                 */
	/* ------------------------------------------------------------------ */

	public function add_menu() {
		add_menu_page(
			'Exhibitions',
			'Exhibitions',
			'manage_options',
			'rhg-exhibitions',
			array( $this, 'render_registrations_page' ),
			'dashicons-tickets-alt',
			26
		);

		add_submenu_page(
			'rhg-exhibitions',
			'Registrations',
			'Registrations',
			'manage_options',
			'rhg-exhibitions',
			array( $this, 'render_registrations_page' )
		);

		add_submenu_page(
			'rhg-exhibitions',
			'Exhibitions',
			'Exhibitions',
			'manage_options',
			'rhg-exhibitions-list',
			array( $this, 'render_exhibitions_page' )
		);

		add_submenu_page(
			'rhg-exhibitions',
			'Settings',
			'Settings',
			'manage_options',
			'rhg-exhibitions-settings',
			array( $this, 'render_settings_page' )
		);
	}

	/* ------------------------------------------------------------------ */
	/* ASSETS                                                               */
	/* ------------------------------------------------------------------ */

	public function enqueue_admin_assets( $hook ) {
		$admin_pages = array(
			'toplevel_page_rhg-exhibitions',
			'exhibitions_page_rhg-exhibitions-list',
			'exhibitions_page_rhg-exhibitions-settings',
		);
		if ( ! in_array( $hook, $admin_pages, true ) ) {
			return;
		}
		wp_enqueue_style(
			'rhg-admin-style',
			RHG_EXH_URL . 'assets/css/admin.css',
			array(),
			RHG_EXH_VERSION
		);
	}

	/* ------------------------------------------------------------------ */
	/* HANDLE FORM POSTS                                                    */
	/* ------------------------------------------------------------------ */

	public function handle_actions() {
		if ( isset( $_POST['rhg_exh_save_settings'] ) && check_admin_referer( 'rhg_exh_settings_nonce' ) ) {
			update_option( 'rhg_exh_admin_email',  sanitize_email( $_POST['rhg_exh_admin_email'] ) );
			update_option( 'rhg_exh_admin_email2', sanitize_email( $_POST['rhg_exh_admin_email2'] ) );

			// Save categories
			$new_cats = array();
			$names    = isset( $_POST['cat_name'] )     ? (array) $_POST['cat_name']     : array();
			$keywords = isset( $_POST['cat_keywords'] ) ? (array) $_POST['cat_keywords'] : array();
			foreach ( $names as $i => $name ) {
				$name = sanitize_text_field( $name );
				if ( '' !== $name ) {
					$new_cats[] = array(
						'name'     => $name,
						'keywords' => sanitize_text_field( $keywords[ $i ] ?? '' ),
					);
				}
			}
			if ( ! empty( $new_cats ) ) {
				RHG_Categories::save( $new_cats );
			}

			add_settings_error( 'rhg_exh_settings', 'saved', 'Settings saved.', 'updated' );
		}

		if ( isset( $_POST['rhg_exh_run_scrape_now'] ) && check_admin_referer( 'rhg_exh_settings_nonce' ) ) {
			$count = RHG_Scraper::run();
			add_settings_error( 'rhg_exh_settings', 'scraped', sprintf( 'Scrape complete: %d exhibitions saved/updated.', $count ), 'updated' );
		}
	}

	/* ------------------------------------------------------------------ */
	/* PAGE 1 — REGISTRATIONS                                              */
	/* ------------------------------------------------------------------ */

	public function render_registrations_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		// Filter values from GET.
		$search   = isset( $_GET['rhg_search'] )   ? sanitize_text_field( $_GET['rhg_search'] )   : '';
		$date_range = isset( $_GET['rhg_date'] )   ? sanitize_text_field( $_GET['rhg_date'] )     : '';
		$city     = isset( $_GET['rhg_city'] )     ? sanitize_text_field( $_GET['rhg_city'] )     : '';
		$category = isset( $_GET['rhg_category'] ) ? sanitize_text_field( $_GET['rhg_category'] ) : '';
		$spec_date = isset( $_GET['rhg_spec_date'] ) ? sanitize_text_field( $_GET['rhg_spec_date'] ) : '';

		$rows = RHG_DB::get_all_registrations_filtered( $search, $date_range, $city, $category, $spec_date );

		$cities     = RHG_DB::get_distinct_cities();
		$categories = RHG_DB::get_distinct_categories();
		?>
		<div class="wrap rhg-admin-wrap">
			<h1 class="wp-heading-inline">Registrations</h1>
			<hr class="wp-header-end">

			<form method="get" class="rhg-filter-bar">
				<input type="hidden" name="page" value="rhg-exhibitions" />

				<input
					type="text"
					name="rhg_search"
					value="<?php echo esc_attr( $search ); ?>"
					placeholder="Search name, email, exhibition..."
					class="rhg-filter-input"
				/>

				<select name="rhg_date" class="rhg-filter-select">
					<option value="">All dates</option>
					<option value="1"  <?php selected( $date_range, '1' ); ?>>Within 1 day</option>
					<option value="3"  <?php selected( $date_range, '3' ); ?>>Within 3 days</option>
					<option value="7"  <?php selected( $date_range, '7' ); ?>>Within 7 days</option>
					<option value="30" <?php selected( $date_range, '30' ); ?>>Within 30 days</option>
					<option value="specific" <?php selected( $date_range, 'specific' ); ?>>Specific date</option>
				</select>

				<input
					type="date"
					name="rhg_spec_date"
					value="<?php echo esc_attr( $spec_date ); ?>"
					class="rhg-filter-input rhg-specific-date <?php echo ( 'specific' === $date_range ) ? '' : 'rhg-hidden'; ?>"
				/>

				<select name="rhg_city" class="rhg-filter-select">
					<option value="">All cities</option>
					<?php foreach ( $cities as $c ) : ?>
						<option value="<?php echo esc_attr( $c ); ?>" <?php selected( $city, $c ); ?>><?php echo esc_html( $c ); ?></option>
					<?php endforeach; ?>
				</select>

				<select name="rhg_category" class="rhg-filter-select">
					<option value="">All categories</option>
					<?php foreach ( $categories as $cat ) : ?>
						<option value="<?php echo esc_attr( $cat ); ?>" <?php selected( $category, $cat ); ?>><?php echo esc_html( $cat ); ?></option>
					<?php endforeach; ?>
				</select>

				<button type="submit" class="button button-primary">Filter</button>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=rhg-exhibitions' ) ); ?>" class="button">Reset</a>
			</form>

			<p class="rhg-result-count">
				<?php echo count( $rows ); ?> registration(s) found.
			</p>

			<table class="wp-list-table widefat fixed striped rhg-table">
				<thead>
					<tr>
						<th>Name</th>
						<th>Email</th>
						<th>Job Title</th>
						<th>Country</th>
						<th>Town</th>
						<th>Exhibition</th>
						<th>Expo Date</th>
						<th>Expo City</th>
						<th>Registered On</th>
					</tr>
				</thead>
				<tbody>
					<?php if ( empty( $rows ) ) : ?>
						<tr><td colspan="9" style="text-align:center; padding:20px;">No registrations found matching your filters.</td></tr>
					<?php else : ?>
						<?php foreach ( $rows as $row ) : ?>
							<tr>
								<td><?php echo esc_html( $row->full_name ); ?></td>
								<td><?php echo esc_html( $row->email ); ?></td>
								<td><?php echo esc_html( $row->job_title ); ?></td>
								<td><?php echo esc_html( $row->country ); ?></td>
								<td><?php echo esc_html( $row->town ); ?></td>
								<td><strong><?php echo esc_html( $row->exhibition_title ); ?></strong></td>
								<td><?php echo esc_html( $row->start_date ? date( 'd M Y', strtotime( $row->start_date ) ) : '—' ); ?></td>
								<td><?php echo esc_html( $row->exhibition_city ); ?></td>
								<td><?php echo esc_html( date( 'd M Y, H:i', strtotime( $row->created_at ) ) ); ?></td>
							</tr>
						<?php endforeach; ?>
					<?php endif; ?>
				</tbody>
			</table>
		</div>

		<script>
		(function(){
			var sel = document.querySelector('[name="rhg_date"]');
			var sd  = document.querySelector('.rhg-specific-date');
			if ( sel && sd ) {
				sel.addEventListener('change', function(){
					sd.classList.toggle('rhg-hidden', this.value !== 'specific');
				});
			}
		})();
		</script>
		<?php
	}

	/* ------------------------------------------------------------------ */
	/* PAGE 2 — EXHIBITIONS (only those with registrations + detail view)  */
	/* ------------------------------------------------------------------ */

	public function render_exhibitions_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$view          = isset( $_GET['view'] ) ? sanitize_text_field( $_GET['view'] ) : 'list';
		$exhibition_id = isset( $_GET['exhibition_id'] ) ? absint( $_GET['exhibition_id'] ) : 0;

		if ( 'detail' === $view && $exhibition_id ) {
			$this->render_exhibition_detail( $exhibition_id );
			return;
		}

		// Filter values.
		$f_name     = isset( $_GET['rhg_name'] )     ? sanitize_text_field( $_GET['rhg_name'] )     : '';
		$f_date     = isset( $_GET['rhg_date'] )     ? sanitize_text_field( $_GET['rhg_date'] )     : '';
		$f_city     = isset( $_GET['rhg_city'] )     ? sanitize_text_field( $_GET['rhg_city'] )     : '';
		$f_category = isset( $_GET['rhg_category'] ) ? sanitize_text_field( $_GET['rhg_category'] ) : '';
		$f_spec     = isset( $_GET['rhg_spec_date'] )? sanitize_text_field( $_GET['rhg_spec_date'] ): '';

		$rows       = RHG_DB::get_exhibitions_with_registrations( $f_name, $f_date, $f_city, $f_category, $f_spec );
		$cities     = RHG_DB::get_distinct_cities();
		$categories = RHG_DB::get_distinct_categories();
		?>
		<div class="wrap rhg-admin-wrap">
			<h1 class="wp-heading-inline">Exhibitions with Registrations</h1>
			<hr class="wp-header-end">

			<form method="get" class="rhg-filter-bar">
				<input type="hidden" name="page" value="rhg-exhibitions-list" />

				<input
					type="text"
					name="rhg_name"
					value="<?php echo esc_attr( $f_name ); ?>"
					placeholder="Search exhibition name..."
					class="rhg-filter-input"
				/>

				<select name="rhg_date" class="rhg-filter-select">
					<option value="">All dates</option>
					<option value="1"  <?php selected( $f_date, '1' ); ?>>Within 1 day</option>
					<option value="3"  <?php selected( $f_date, '3' ); ?>>Within 3 days</option>
					<option value="7"  <?php selected( $f_date, '7' ); ?>>Within 7 days</option>
					<option value="30" <?php selected( $f_date, '30' ); ?>>Within 30 days</option>
					<option value="specific" <?php selected( $f_date, 'specific' ); ?>>Specific date</option>
				</select>

				<input
					type="date"
					name="rhg_spec_date"
					value="<?php echo esc_attr( $f_spec ); ?>"
					class="rhg-filter-input rhg-specific-date <?php echo ( 'specific' === $f_date ) ? '' : 'rhg-hidden'; ?>"
				/>

				<select name="rhg_city" class="rhg-filter-select">
					<option value="">All cities</option>
					<?php foreach ( $cities as $c ) : ?>
						<option value="<?php echo esc_attr( $c ); ?>" <?php selected( $f_city, $c ); ?>><?php echo esc_html( $c ); ?></option>
					<?php endforeach; ?>
				</select>

				<select name="rhg_category" class="rhg-filter-select">
					<option value="">All categories</option>
					<?php foreach ( $categories as $cat ) : ?>
						<option value="<?php echo esc_attr( $cat ); ?>" <?php selected( $f_category, $cat ); ?>><?php echo esc_html( $cat ); ?></option>
					<?php endforeach; ?>
				</select>

				<button type="submit" class="button button-primary">Filter</button>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=rhg-exhibitions-list' ) ); ?>" class="button">Reset</a>
			</form>

			<p class="rhg-result-count"><?php echo count( $rows ); ?> exhibition(s) with registrations.</p>

			<table class="wp-list-table widefat fixed striped rhg-table">
				<thead>
					<tr>
						<th>Exhibition Name</th>
						<th>Date</th>
						<th>City</th>
						<th>Venue</th>
						<th>Category</th>
						<th>Registrations</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody>
					<?php if ( empty( $rows ) ) : ?>
						<tr><td colspan="7" style="text-align:center; padding:20px;">No exhibitions with registrations found.</td></tr>
					<?php else : ?>
						<?php foreach ( $rows as $row ) : ?>
							<tr>
								<td><strong><?php echo esc_html( $row->title ); ?></strong></td>
								<td><?php echo esc_html( $row->start_date ? date( 'd M Y', strtotime( $row->start_date ) ) : '—' ); ?></td>
								<td><?php echo esc_html( $row->city ); ?></td>
								<td><?php echo esc_html( $row->venue ); ?></td>
								<td><?php echo esc_html( $row->category ); ?></td>
								<td>
									<span class="rhg-badge"><?php echo (int) $row->total_registrations; ?></span>
								</td>
								<td>
									<a href="<?php echo esc_url( admin_url( 'admin.php?page=rhg-exhibitions-list&view=detail&exhibition_id=' . $row->id ) ); ?>" class="button button-small">View Registrants</a>
								</td>
							</tr>
						<?php endforeach; ?>
					<?php endif; ?>
				</tbody>
			</table>
		</div>

		<script>
		(function(){
			var sel = document.querySelector('[name="rhg_date"]');
			var sd  = document.querySelector('.rhg-specific-date');
			if ( sel && sd ) {
				sel.addEventListener('change', function(){
					sd.classList.toggle('rhg-hidden', this.value !== 'specific');
				});
			}
		})();
		</script>
		<?php
	}

	private function render_exhibition_detail( $exhibition_id ) {
		$exhibition = RHG_DB::get_exhibition_by_id( $exhibition_id );
		if ( ! $exhibition ) {
			echo '<div class="wrap"><p>Exhibition not found.</p></div>';
			return;
		}
		$registrations = RHG_DB::get_registrations_for_exhibition( $exhibition_id );
		?>
		<div class="wrap rhg-admin-wrap">
			<p>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=rhg-exhibitions-list' ) ); ?>">&larr; Back to exhibitions</a>
			</p>
			<h1><?php echo esc_html( $exhibition->title ); ?></h1>
			<p class="rhg-expo-meta">
				📅 <?php echo esc_html( $exhibition->start_date ? date( 'd M Y', strtotime( $exhibition->start_date ) ) : '—' ); ?>
				&nbsp;&nbsp;📍 <?php echo esc_html( $exhibition->venue . ', ' . $exhibition->city ); ?>
				&nbsp;&nbsp;🏷️ <?php echo esc_html( $exhibition->category ); ?>
			</p>

			<h2 style="margin-top:24px;"><?php echo count( $registrations ); ?> Registrant(s)</h2>

			<table class="wp-list-table widefat fixed striped rhg-table">
				<thead>
					<tr>
						<th>Name</th>
						<th>Email</th>
						<th>Job Title</th>
						<th>Country</th>
						<th>Town</th>
						<th>Registered On</th>
					</tr>
				</thead>
				<tbody>
					<?php if ( empty( $registrations ) ) : ?>
						<tr><td colspan="6" style="text-align:center; padding:20px;">No registrations yet.</td></tr>
					<?php else : ?>
						<?php foreach ( $registrations as $r ) : ?>
							<tr>
								<td><?php echo esc_html( $r->full_name ); ?></td>
								<td><?php echo esc_html( $r->email ); ?></td>
								<td><?php echo esc_html( $r->job_title ); ?></td>
								<td><?php echo esc_html( $r->country ); ?></td>
								<td><?php echo esc_html( $r->town ); ?></td>
								<td><?php echo esc_html( date( 'd M Y, H:i', strtotime( $r->created_at ) ) ); ?></td>
							</tr>
						<?php endforeach; ?>
					<?php endif; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	/* ------------------------------------------------------------------ */
	/* PAGE 3 — SETTINGS                                                   */
	/* ------------------------------------------------------------------ */

	public function render_settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$admin_email  = get_option( 'rhg_exh_admin_email',  get_option( 'admin_email' ) );
		$admin_email2 = get_option( 'rhg_exh_admin_email2', '' );
		$last_run     = get_option( 'rhg_exh_last_run' );
		$last_count   = get_option( 'rhg_exh_last_run_count' );
		?>
		<div class="wrap rhg-admin-wrap">
			<h1>Royal Hermes Exhibitions — Settings</h1>

			<?php settings_errors( 'rhg_exh_settings' ); ?>

			<?php
			$last_error  = get_option( 'rhg_exh_last_error' );
			$last_status = get_option( 'rhg_exh_last_http_status' );
			$last_length = get_option( 'rhg_exh_last_body_length' );
			if ( ! empty( $last_error ) ) : ?>
				<div class="notice notice-error" style="padding:16px; border-left-width:6px;">
					<p style="font-size:15px; margin:0 0 8px;"><strong>⚠️ Last scrape error — copy this and send it to support:</strong></p>
					<textarea readonly rows="4" style="width:100%; font-family:monospace; font-size:13px; background:#fff; padding:10px;"><?php echo esc_textarea( $last_error ); ?></textarea>
				</div>
			<?php elseif ( $last_status ) : ?>
				<div class="notice notice-info" style="padding:12px 16px;">
					<p><strong>Last successful fetch:</strong> HTTP <?php echo esc_html( $last_status ); ?>, <?php echo esc_html( number_format( (int) $last_length ) ); ?> bytes received.</p>
				</div>
			<?php endif; ?>

			<div class="notice notice-warning" style="padding:12px 16px;">
				<p><strong>Email delivery note:</strong> Install <strong>WP Mail SMTP</strong> or <strong>Easy WP SMTP</strong> and connect to Gmail/SendGrid for reliable email delivery.</p>
			</div>

			<form method="post">
				<?php wp_nonce_field( 'rhg_exh_settings_nonce' ); ?>
				<h2>Admin Notification Emails</h2>
				<p>Both addresses below will receive an email whenever a visitor registers for an exhibition.</p>
				<table class="form-table">
					<tr>
						<th scope="row"><label for="rhg_exh_admin_email">Admin Email 1</label></th>
						<td>
							<input type="email" id="rhg_exh_admin_email" name="rhg_exh_admin_email"
								value="<?php echo esc_attr( $admin_email ); ?>" class="regular-text" />
							<p class="description">Primary notification address. Defaults to WordPress admin email.</p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="rhg_exh_admin_email2">Admin Email 2</label></th>
						<td>
							<input type="email" id="rhg_exh_admin_email2" name="rhg_exh_admin_email2"
								value="<?php echo esc_attr( $admin_email2 ); ?>" class="regular-text" />
							<p class="description">Second notification address (optional). Leave blank to disable.</p>
						</td>
					</tr>
				</table>
				<p class="submit">
					<input type="submit" name="rhg_exh_save_settings" class="button button-primary" value="Save Settings" />
				</p>
			</form>

			<hr />

			<h2>Category Management</h2>
			<p>These categories are used to automatically tag exhibitions when scraped, and appear as filter pills on your website. Keywords are comma-separated — the first category whose keywords match the exhibition title or description wins. The last row (no keywords) is the catch-all fallback.</p>
			<p><strong>After changing keywords, click "Run Scrape Now" below to re-categorise all exhibitions.</strong></p>

			<table class="wp-list-table widefat fixed" id="rhg-cat-table" style="margin-bottom:12px;">
				<thead>
					<tr>
						<th style="width:28%">Category Name</th>
						<th>Keywords (comma-separated, case-insensitive)</th>
						<th style="width:80px;">Remove</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( RHG_Categories::get_all() as $i => $cat ) : ?>
					<tr class="rhg-cat-row">
						<td>
							<input type="text" name="cat_name[]"
								value="<?php echo esc_attr( $cat['name'] ); ?>"
								class="regular-text" style="width:100%;" />
						</td>
						<td>
							<input type="text" name="cat_keywords[]"
								value="<?php echo esc_attr( $cat['keywords'] ); ?>"
								placeholder="e.g. solar,energy,green,wind"
								style="width:100%;" />
						</td>
						<td style="text-align:center;">
							<button type="button" class="button rhg-remove-cat" style="color:#e63950;">✕</button>
						</td>
					</tr>
					<?php endforeach; ?>
				</tbody>
			</table>

			<button type="button" id="rhg-add-cat" class="button">+ Add Category</button>

			<script>
			(function(){
				document.getElementById('rhg-add-cat').addEventListener('click', function(){
					var tbody = document.querySelector('#rhg-cat-table tbody');
					var row   = document.createElement('tr');
					row.className = 'rhg-cat-row';
					row.innerHTML = '<td><input type="text" name="cat_name[]" class="regular-text" style="width:100%;" placeholder="Category name" /></td>'
						+ '<td><input type="text" name="cat_keywords[]" style="width:100%;" placeholder="keyword1,keyword2,keyword3" /></td>'
						+ '<td style="text-align:center;"><button type="button" class="button rhg-remove-cat" style="color:#e63950;">✕</button></td>';
					tbody.appendChild(row);
				});
				document.addEventListener('click', function(e){
					if ( e.target && e.target.classList.contains('rhg-remove-cat') ) {
						e.target.closest('tr').remove();
					}
				});
			})();
			</script>

			<hr />
			<p>
				<?php if ( $last_run ) : ?>
					Last scrape: <strong><?php echo esc_html( date( 'd M Y, H:i', strtotime( $last_run ) ) ); ?></strong>
					— <?php echo esc_html( (int) $last_count ); ?> exhibitions saved/updated.
				<?php else : ?>
					No scrape has run yet.
				<?php endif; ?>
				This runs automatically once a day.
			</p>
			<form method="post">
				<?php wp_nonce_field( 'rhg_exh_settings_nonce' ); ?>
				<input type="submit" name="rhg_exh_run_scrape_now" class="button button-secondary" value="Run Scrape Now" />
			</form>

			<hr />

			<h2>Shortcode</h2>
			<p>Add this shortcode to any page or post to display the exhibition listing:</p>
			<code>[rhg_exhibitions]</code>
		</div>
		<?php
	}
}
