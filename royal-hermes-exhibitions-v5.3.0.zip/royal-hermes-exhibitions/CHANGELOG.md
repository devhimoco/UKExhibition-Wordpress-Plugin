# Royal Hermes Exhibitions — Changelog

Versioning rules:
- **+0.1** for small changes (bug fixes, minor UI tweaks, small feature additions)
- **+1.0** for big changes (new pages, new systems, major redesigns, new integrations)
- Starting point: **v5.0.0**

Each zip delivered is named with its version so you can always identify and reinstall a previous release.

---

## v5.3.0 — 2026-07-02
**Small release — Other category + closed accordion + card hover overlay**

### What changed
- **Category:** renamed catch-all `Business Services` → `Other` (all 119 unmatched exhibitions now land here instead of showing "Business" as a category). Migration runs automatically on plugin load for existing installs
- **Admin accordion:** all category blocks now **start closed** by default — admin clicks to open whichever they want
- **Card redesign:** visible card now shows only short title (max 42 chars), date, **days-left badge** (gold border, bold), and location — no description or register button cluttering the front
- **Days-left badge:** shows "X days to go" in gold for future expos, "Today!" in red if same-day, "Ended" greyed-out for past
- **Hover overlay:** red semi-transparent overlay (92% opacity) fades in on mouse-over showing full exhibition title, date + days-left, location, description (28 words), and the Register button (white with red text). Overlay slides up smoothly (CSS transition)
- Register button moved **inside the overlay only** — cleaner card at rest

---

## v5.2.0 — 2026-07-02
**Small release — Admin accordion + multi-select category filter**

### What changed
- Admin → Exhibitions page completely rebuilt as **accordion by category**
  - One collapsible block per category
  - Header shows: category name / expo count / total registrations (green)
  - Categories with registrations auto-expand and appear first (most → least)
  - Inside each block: table of all expos, registered ones first with red badge; unregistered show "—"
  - Click "View Registrants" on any registered expo → detail page unchanged
- Front-end category pills now support **multi-select** — click multiple pills to filter by several categories at once; "All Categories" clears selection
- Active filter label shows all selected category names comma-separated with "× Clear all"
- DB `get_exhibitions()` now accepts string or array for category filter (IN clause)
- AJAX handler decodes JSON-encoded category array from front end

---

## v5.1.0 — 2026-07-02
**Small release — Category system + 4-column grid**

### What changed
- Added `class-rhg-categories.php` — keyword-based auto-categorisation engine
- 20 default categories shipped (Automotive, Aerospace, Construction, Energy, Tech, Food, Healthcare, Fashion, Finance, Marketing, Manufacturing, Logistics, Real Estate, Education, Science, Agriculture, Sports, Printing, Franchise, Business Services)
- Scraper now calls `RHG_Categories::auto_assign()` instead of hardcoding 'Business'
- Settings page: full Category Management table (add, edit, remove categories + keywords)
- Website: category filter pills above the grid ("All Categories" + one pill per category)
- Active filter label with "× Clear" button
- Grid changed from 3 to **4 columns** (responsive: 3 on tablet, 2 on mobile, 1 on small mobile)
- Default per-page changed from 10 to **20**
- `get_exhibitions()` DB query updated to accept `$category` filter param
- AJAX filter handler passes category through

---

## v5.0.0 — 2026-07-02
**Major release — starting version**

### What's in this version
- Scrapes UK B2B trade shows daily from EventsEye (no robots.txt blocking, polite 1-second delay between pages)
- Custom DB tables: `rhg_exhibitions` + `rhg_registrations`
- Daily WP-Cron job with manual "Run Scrape Now" button
- Front-end shortcode `[rhg_exhibitions]` with:
  - Live search (debounced)
  - Show 10 / 20 / 40 / 50 dropdown
  - Paginated grid of cards (navy/red/gold brand colours)
  - Registration popup modal per exhibition
  - Server-side email validation (@ + valid domain required)
- Emails on registration: customer confirmation + dual admin notifications
- Admin → Registrations page: filterable by keyword, date range (1/3/7/30 days or specific date), city, category
- Admin → Exhibitions page: only shows exhibitions with ≥1 registration; filterable; click-through to registrant list
- Admin → Settings page: 2 admin notification email fields, scraper controls, shortcode reference
- XAMPP SSL fix baked in (`sslverify => false`, real browser User-Agent)
- Detailed scrape error logging with copy-pasteable admin error box
- Versioned CHANGELOG (this file)

---

## How to read the version number

```
v  5  .  0  .  0
   │     │     └─ patch: tiny fixes (typos, CSS tweaks)
   │     └─ minor: small features or bug fixes  (+0.1 per release)
   └─ major: big new features, pages, integrations  (+1.0 per release)
```

Future entries go at the TOP of this file, newest first.

---

*Next version will be v5.1.0 for the next small change, or v6.0.0 for the next big one.*
